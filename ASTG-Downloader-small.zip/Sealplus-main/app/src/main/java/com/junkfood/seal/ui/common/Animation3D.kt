package com.junkfood.seal.ui.common

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize

/** Slow, continuous 3D sway (rotation on X and Y with perspective). */
fun Modifier.floating3D(maxAngle: Float = 12f, periodMs: Int = 3600): Modifier = composed {
    val density = LocalDensity.current.density
    val transition = rememberInfiniteTransition(label = "floating3D")
    val rotY by
        transition.animateFloat(
            initialValue = -maxAngle,
            targetValue = maxAngle,
            animationSpec =
                infiniteRepeatable(
                    animation = tween(periodMs, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse,
                ),
            label = "rotY",
        )
    val rotX by
        transition.animateFloat(
            initialValue = maxAngle / 2f,
            targetValue = -maxAngle / 2f,
            animationSpec =
                infiniteRepeatable(
                    animation = tween(periodMs + 1300, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse,
                ),
            label = "rotX",
        )
    this.graphicsLayer {
        rotationY = rotY
        rotationX = rotX
        cameraDistance = 14f * density
    }
}

/** Tilts toward the finger in 3D while touched, springs back on release. Never consumes touches. */
fun Modifier.tilt3D(maxAngle: Float = 16f): Modifier = composed {
    val density = LocalDensity.current.density
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var tx by remember { mutableStateOf(0f) }
    var ty by remember { mutableStateOf(0f) }
    val angleY by
        animateFloatAsState(
            targetValue = tx * maxAngle,
            animationSpec =
                spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow,
                ),
            label = "tiltY",
        )
    val angleX by
        animateFloatAsState(
            targetValue = ty * maxAngle,
            animationSpec =
                spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow,
                ),
            label = "tiltX",
        )
    this.onSizeChanged { boxSize = it }
        .pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val change = event.changes.firstOrNull()
                    if (change != null && change.pressed && boxSize.width > 0 && boxSize.height > 0) {
                        tx = ((change.position.x / boxSize.width) * 2f - 1f).coerceIn(-1f, 1f)
                        ty = ((change.position.y / boxSize.height) * 2f - 1f).coerceIn(-1f, 1f)
                    } else {
                        tx = 0f
                        ty = 0f
                    }
                }
            }
        }
        .graphicsLayer {
            rotationY = angleY
            rotationX = -angleX
            cameraDistance = 14f * density
        }
}
